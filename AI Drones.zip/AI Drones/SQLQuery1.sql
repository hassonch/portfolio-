create database Ai_Drones;
-- Table: Users
CREATE TABLE Users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    role ENUM('admin', 'staff', 'viewer') NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL
);

-- Table: Drones
CREATE TABLE Drones (
    drone_id INT PRIMARY KEY AUTO_INCREMENT,
    status ENUM('idle', 'patrolling', 'charging', 'offline') NOT NULL,
    battery_level DECIMAL(5,2) NOT NULL,
    location VARCHAR(255),
    assigned_user INT,
    FOREIGN KEY (assigned_user) REFERENCES Users(user_id)
);

-- Table: PatrolRoutes
CREATE TABLE PatrolRoutes (
    route_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    coordinates TEXT NOT NULL, -- Could be GeoJSON or delimited string
    drone_id INT,
    FOREIGN KEY (drone_id) REFERENCES Drones(drone_id)
);

-- Table: Alerts
CREATE TABLE Alerts (
    alert_id INT PRIMARY KEY AUTO_INCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    drone_id INT,
    type VARCHAR(100), -- e.g., "motion detected", "intruder alert"
    location VARCHAR(255),
    image_path VARCHAR(255),
    resolved BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (drone_id) REFERENCES Drones(drone_id)
);

-- Table: VideoLogs
CREATE TABLE VideoLogs (
    video_id INT PRIMARY KEY AUTO_INCREMENT,
    drone_id INT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    duration INT, -- in seconds
    file_path VARCHAR(255),
    FOREIGN KEY (drone_id) REFERENCES Drones(drone_id)
);

-- Table: SystemLogs
CREATE TABLE SystemLogs (
    log_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    action VARCHAR(255),
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES Users(user_id)
);
